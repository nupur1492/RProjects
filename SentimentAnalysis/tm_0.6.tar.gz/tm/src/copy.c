#include <Rinternals.h>

void copyCorpus(SEXP x, SEXP y)
{
    copyVector(x, y);
}
